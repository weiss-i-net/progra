
public interface WritableMap <K, V> extends ReadableMap <K, V>
{
    public void put (K key, V value);
}
